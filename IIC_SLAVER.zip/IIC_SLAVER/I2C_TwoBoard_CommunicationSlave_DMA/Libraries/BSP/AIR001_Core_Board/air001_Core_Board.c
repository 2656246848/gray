#include "air001_Core_Board.h"

#define __AIR001_CORE_BOARD_BSP_VERSION_MAIN (0x01U) /*!< [31:24] main version */
#define __AIR001_CORE_BOARD_BSP_VERSION_SUB1 (0x00U) /*!< [23:16] sub1 version */
#define __AIR001_CORE_BOARD_BSP_VERSION_SUB2 (0x00U) /*!< [15:8]  sub2 version */
#define __AIR001_CORE_BOARD_BSP_VERSION_RC (0x00U)   /*!< [7:0]  release candidate */
#define __AIR001_CORE_BOARD_BSP_VERSION ((__AIR001_CORE_BOARD_BSP_VERSION_MAIN << 24) | (__AIR001_CORE_BOARD_BSP_VERSION_SUB1 << 16) | (__AIR001_CORE_BOARD_BSP_VERSION_SUB2 << 8) | (__AIR001_CORE_BOARD_BSP_VERSION_RC))

#ifdef HAL_UART_MODULE_ENABLED
UART_HandleTypeDef DebugUartHandle;
#endif


/**
 * @brief 该方法返回AIR001 CORE BOARD BSP Driver的版本。
 * @retval version : 0xXYZR (8bits for each decimal, R for RC)
 */
uint32_t BSP_GetVersion(void)
{
  return __AIR001_CORE_BOARD_BSP_VERSION;
}

/** @addtogroup LED_Functions
 * @{
 */

/**
 * @brief 配置LED的GPIO。
 * @param Led 指定要配置的LED。
 * 这个参数可以是以下的参数之一：
 * @arg LED1
 * @retval 无
 */
void BSP_LED_Init(Led_TypeDef Led)
{
  GPIO_InitTypeDef GPIO_InitStruct;

  /* Enable the GPIO_LED Clock */
	__HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* Configure the GPIO_LED pin */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;

  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET);
}

void BSP_LED5_Init()
{
  GPIO_InitTypeDef GPIO_InitStruct;

  /* Enable the GPIO_LED Clock */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* Configure the GPIO_LED pin */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
}

/**
 * @brief DeInitialize LED GPIO.
 * @param Led 指定要去配置的LED。
 * 这个参数可以是以下值之一：
 * @arg LED1
 * @注意 BSP_LED_DeInit()不会禁用GPIO时钟。
 * @retval 无
 */
void BSP_LED_DeInit(Led_TypeDef Led)
{
  GPIO_InitTypeDef GPIO_InitStruct;

  /* Turn off LED */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
  /* DeInit the GPIO_LED pin */
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  HAL_GPIO_DeInit(GPIOA, GPIO_PIN_6);
}

/**
 * @brief 将选定的LED打开。
 * @param Led 指定要设置的LED。
 * 这个参数可以是以下的参数之一：
 * @arg LED1
 * @retval 无
 */
void BSP_LED_On(Led_TypeDef Led)
{
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET);
}

/**
 * @brief 将选定的LED关闭。
 * @param Led 指定要关闭的LED。
 * 这个参数可以是下列参数之一：
 * @arg LED1
 * @retval 无
 */
void BSP_LED_Off(Led_TypeDef Led)
{
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
}

/**
 * @brief 切换选定的LED电平。
 * @param Led 指定要切换的LED。
 * 这个参数可以是下列参数之一：
 * @arg LED1
 * @retval 无
 */
void BSP_LED_Toggle(Led_TypeDef Led)
{
  HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_6);
}



#ifdef HAL_UART_MODULE_ENABLED
/**
 * @brief DEBUG_USART GPIO配置,模式配置,115200 8-N-1
 * @param None
 * @retval 无
 */
void BSP_USART_Config(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;

  DEBUG_USART_CLK_ENABLE();

  DebugUartHandle.Instance = DEBUG_USART;

  DebugUartHandle.Init.BaudRate = DEBUG_USART_BAUDRATE;
  DebugUartHandle.Init.WordLength = UART_WORDLENGTH_8B;
  DebugUartHandle.Init.StopBits = UART_STOPBITS_1;
  DebugUartHandle.Init.Parity = UART_PARITY_NONE;
  DebugUartHandle.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  DebugUartHandle.Init.Mode = UART_MODE_TX;

  HAL_UART_Init(&DebugUartHandle);

  DEBUG_USART_TX_GPIO_CLK_ENABLE();

  /**USART GPIO Configuration
   // PA7     ------> USART1_RX
    */
  GPIO_InitStruct.Pin = DEBUG_USART_TX_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = DEBUG_USART_TX_AF;//复用为USART2
  HAL_GPIO_Init(DEBUG_USART_TX_GPIO_PORT, &GPIO_InitStruct);
  HAL_NVIC_SetPriority(USART2_IRQn, 0, 1);
  HAL_NVIC_EnableIRQ(USART2_IRQn);

}
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
}
void USART2_IRQHandler(void)
{
    HAL_UART_IRQHandler(&DebugUartHandle);
}

void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin : PB0 */
  GPIO_InitStruct.Pin = GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

#if (defined(__CC_ARM)) || (defined(__ARMCC_VERSION) && (__ARMCC_VERSION >= 6010050))
/**
 * @brief 写一个字符到usart中。
 *@param ch
 * *f
 *@retval 该字符
 */
int fputc(int ch, FILE *f)
{
  /* Send a byte to USART */
  HAL_UART_Transmit(&DebugUartHandle, (uint8_t *)&ch, 1, 1000);

  return (ch);
}

/**
 *@brief 从usart中获取一个字符
 *@param *f
 *@retval 一个字符
 */
int fgetc(FILE *f)
{
  int ch;
  HAL_UART_Receive(&DebugUartHandle, (uint8_t *)&ch, 1, 1000);
  return (ch);
}

#elif defined(__ICCARM__)
/**
 * @brief 写一个字符到usart中。
 *@param ch
 * *f
 *@retval 该字符
 */
int putchar(int ch)
{
  /* Send a byte to USART */
  HAL_UART_Transmit(&DebugUartHandle, (uint8_t *)&ch, 1, 1000);

  return (ch);
}
#endif

#endif

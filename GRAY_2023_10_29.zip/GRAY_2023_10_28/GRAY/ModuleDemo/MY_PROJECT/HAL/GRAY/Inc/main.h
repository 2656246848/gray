/**
  ******************************************************************************
  * @file    main.h
  * @author  MCU Application Team
  * @brief   Header for main.c file.
  *          This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) AirM2M.
  * All rights reserved.</center></h2>
  *
  * <h2><center>&copy; Copyright (c) 2016 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

#define IIC_LL 		1
//#define IIC_HAL 		1
//#define IIC_sf 1
/* Includes ------------------------------------------------------------------*/
#include "air001xx_hal.h"
#include "air001_Core_Board.h"
#include "air001xx_ll_rcc.h"
#include "air001xx_ll_bus.h"
#include "air001xx_ll_system.h"
#include "air001xx_ll_cortex.h"
#include "air001xx_ll_utils.h"
#include "air001xx_ll_pwr.h"
#include "air001xx_ll_dma.h"
#include "air001xx_ll_gpio.h"
#include "air001xx_ll_i2c.h"

//extern struct Node *headR1max;
//extern struct Node *headR1min;
//extern struct Node *headL1max;
//extern struct Node *headL1min;
//extern struct Node *headR2max;
//extern struct Node *headR2min;
//extern struct Node *headL2max;
//extern struct Node *headL2min;
//extern struct Node *headMidmax;
//extern struct Node *headMidmin;
extern volatile char MODE_WORK;
extern char TEST_FINSH;
extern volatile uint32_t task_count ;
extern volatile uint8_t COMMUNICATION_MODE;
extern uint8_t ans[6];
uint8_t compare(uint8_t num);
/* Private includes ----------------------------------------------------------*/
/* Private defines -----------------------------------------------------------*/
/* Exported variables prototypes ---------------------------------------------*/
/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);
extern uint8_t *node_num;
//extern volatile uint16_t wait;
#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT AirM2M *****END OF FILE******************/

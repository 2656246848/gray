#include "main.h"
#include "iic.h"
#include "iic_ll.h"
#include "air001xx_it.h"
#include "timer.h"
#include "adc.h"
/* Private includes ----------------------------------------------------------*/
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private user code ---------------------------------------------------------*/
/* External variables --------------------------------------------------------*/

/******************************************************************************/
/*           Cortex-M0+ Processor Interruption and Exception Handlers         */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  while (1)
  {
	  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);//L2~R2灯灭掉，表示校验失败
	  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
	  printf("请重新上电校验 \r\n");
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  HAL_IncTick();
}

/*中断*/
//void TIM14_IRQHandler(void)
//{
//  HAL_TIM_IRQHandler(&Tim14);
//}

void TIM3_IRQHandler(void)
{
  HAL_TIM_IRQHandler(&Tim3);
}

#ifdef IIC_LL
void I2C1_IRQHandler(void)
{
  APP_SlaveIRQCallback();
  APP_SlaveIRQCallback_NACK();
}
void DMA1_Channel1_IRQHandler(void)
{
  APP_DmaIRQCallback();
}

void DMA1_Channel2_3_IRQHandler(void)
{
  APP_DmaIRQCallback();
}
#endif
#ifdef IIC_HAL
void DMA1_Channel1_IRQHandler(void)
{
  HAL_DMA_IRQHandler(I2cHandle.hdmatx);
}

/**
  * @brief This function handles DMA1 channel2 and channel2 Interrupt .
  */
void DMA1_Channel2_3_IRQHandler(void)
{
  HAL_DMA_IRQHandler(I2cHandle.hdmarx);
}

/**
  * @brief This function handles I2C1 Interrupt .
  */
void I2C1_IRQHandler(void)
{
  HAL_I2C_EV_IRQHandler(&I2cHandle);
}
#endif

/************************ (C) COPYRIGHT AirM2M *****END OF FILE******************/

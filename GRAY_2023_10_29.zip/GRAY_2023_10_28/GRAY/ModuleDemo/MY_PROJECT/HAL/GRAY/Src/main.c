#include "main.h"
#include "timer.h"
#include "adc.h"
#include "filter.h"
#include "datastore.h"
#include "adjusting.h"
//#include "iic.h"
#include "iic_ll.h"
//#include "iic_software.h"

// 全局链表头指针 
struct Node *headR2max = NULL;
struct Node *headR2min = NULL;
struct Node *headL2max = NULL;
struct Node *headL2min = NULL;
struct Node *headR1max = NULL;
struct Node *headR1min = NULL;
struct Node *headL1max = NULL;
struct Node *headL1min = NULL;
struct Node *headMidmax = NULL;
struct Node *headMidmin = NULL;
TESTDATA R2;TESTDATA L2;
TESTDATA R1;
TESTDATA L1;TESTDATA MID;//颜色信息储存


uint8_t *node_num;
#define sample_times	125//校准模式采样次数
volatile uint32_t task_count = 0;

volatile uint8_t COMMUNICATION_MODE = 0x01;//默认串口模式
#define IIC    0x00
#define USART  0x01
static u16 divp[5]={1000,1000,1000,1000,1000};
/*工作模式设定*/
volatile char MODE_WORK = 1;
uint16_t *sim_cn=NULL;
//uint16_t sim_conut=0;//校准模式下的采样次数
char TEST_FINSH = 0;//校准模式采集完成标志位
uint8_t ans[6]={2,2,2,2,2,0xB5};//比较结果，正常是0或1
uint8_t bit1;uint8_t bit2;
//volatile uint16_t wait = 0;
//volatile uint8_t address = 0xFF;

/*函数声明*/
static void APP_SystemClockConfig(void);
uint8_t compare(uint8_t num);
static void M1(void);
static void M2(void);


int main(void)
{
	bit1=0;bit2=0;
	//address = 0;//wait=0;//在条件编译里首次出现的变量数值显示有误，故在此处调用一下
	sim_cn=(uint16_t*)malloc(sizeof(uint16_t));
	*sim_cn = 0;
	/* 初始化所有外设，Flash接口，SysTick */
	HAL_Init();  
	/* 系统时钟配置 */
	APP_SystemClockConfig(); 
	/* 初始化LED *///工作模式led闪烁1s/次。颜色切换准备时led熄灭。校准采集时led常亮。
	BSP_LED5_Init();
	//clc=HAL_RCC_GetSysClockFreq();//获取系统时钟频率
	MX_TIM3_Init();
	APP_AdcConfig();
	HAL_TIM_Base_MspInit(&Tim3);
	MX_GPIO_Init();//PA5初始化，接3.3v进入校准模式，否则正常工作
	MODE_WORK =HAL_GPIO_ReadPin (GPIOA,GPIO_PIN_5);
	
	if(!MODE_WORK)//工作模式
	{
	   u8 divp2[12];
	   STMFLASH_Read(FLASH_USER_START_ADDR,(u16*)divp2,sizeof(divp2)+2);
	   for(u8 i=0;i<5;i++)
	   {
		   divp[i]=16*divp2[2*i]+divp2[2*i+1];
		   if(divp[i]>4095||divp[i]<0)
		   {
			  divp[i]=500;
		   }
	   }
	   COMMUNICATION_MODE = divp2[10]&divp2[11];//设置通信模式
	   if(COMMUNICATION_MODE == IIC)//-----------------!!!!!!!!!!!!!!IIC模式跳完后改回==
	   {
		   #ifdef IIC_HAL
			My_IIC_INIT();
			#endif
		    #ifdef IIC_LL
			APP_ConfigI2cSlave_LL();
//		   while((bit1!=1)||(bit2!=1))
//			{
//				bit1=LL_GPIO_IsInputPinSet(GPIOF, LL_GPIO_PIN_0);//读SDA
//				LL_uDelay(10);
//				bit2=LL_GPIO_IsInputPinSet(GPIOF, LL_GPIO_PIN_1);
//			}
	        #endif
		    #ifdef IIC_sf
		    //MyI2C_Init();
		     MyIIC_Init();
		    #endif
		   
	   }  
	   else
	   {
			BSP_USART_Config();//串口初始化
		    printf("分界值=%d,%d,%d,%d,%d\r\n",divp[0],divp[1],divp[2],divp[3],divp[4]);
	   }
	   
	}
	else//校准模式
	{
		node_num = (u8*)malloc(10*sizeof(u8));
		for(u8 i = 0;i<10;i++)
		{
			node_num[i]=0;
		}
		
		//-----选择通信模式---------
		 MX_GPIO2_Init();//PA7(TX)初始化，用于设置通信模式
		 HAL_Delay(1000);
		COMMUNICATION_MODE=(HAL_GPIO_ReadPin (GPIOA,GPIO_PIN_7));
		HAL_Delay(1000);//2s时间准备
		 HAL_GPIO_DeInit(GPIOA, GPIO_PIN_7);
		BSP_USART_Config();//串口初始化
	}
  
	/* 无限循环 */
	while (1)
	{
	  if(MODE_WORK)//校准模式
	  {
		  M1();
	  }
	  else//工作模式
	  { 
		  M2();
	  }
	}
}

/*-----#####################自定义函数###############################--------*/
uint8_t compare(uint8_t num)
{
	if(divp[num]>adc_value[num])
	//if(divp[num]>average_value[num])
	{
		return 0;
	}
	return 1;
}

/*校准模式流程*/
static void M1(void)
{
  if(Timer_5ms_Task==1)//5ms串口显示1欿
  {
		Timer_5ms_Task=0;
		if(*sim_cn<sample_times)//采样未完成
		{
			//HAL_TIM_Base_Stop(&Tim3);//暂停定时器
			ADC_sampling();//adc采集 
			//MedianValueAverageFiltering((uint16_t *)adc_value);//adc滤波器
			insertSorted_max(&headR2max, adc_value[4],0);//链表加入数据
			insertSorted_min(&headR2min, adc_value[4],1);
			insertSorted_max(&headL2max, adc_value[0],2);
			insertSorted_min(&headL2min, adc_value[0],3);
			insertSorted_max(&headR1max, adc_value[3],4);
			insertSorted_min(&headR1min, adc_value[3],5);
			insertSorted_max(&headL1max, adc_value[1],6);
			insertSorted_min(&headL1min, adc_value[1],7);
			insertSorted_max(&headMidmax, adc_value[2],8);
			insertSorted_min(&headMidmin, adc_value[2],9);
			*sim_cn+=1;
			//printf("%d\r\n",sim_conut);
			//HAL_TIM_Base_Start(&Tim3);//启动定时器
		}
		else if(*sim_cn==sample_times)//采样结束
		{
				//打印链表内容
				print_list(&headR2max);print_list(&headR2min);
				print_list(&headL2max);print_list(&headL2min);
				print_list(&headR1max);print_list(&headR1min);
				print_list(&headL1max);print_list(&headL1min);
				print_list(&headMidmax);print_list(&headMidmin);
//						R2.max[TEST_FINSH]=headR2max->site;	R2.min[TEST_FINSH]=headR2min->site;
//						L2.max[TEST_FINSH]=headL2max->site;	L2.min[TEST_FINSH]=headL2min->site;
//						R1.max[TEST_FINSH]=headR1max->site;	R1.min[TEST_FINSH]=headR1min->site;
//						L1.max[TEST_FINSH]=headL1max->site;	L1.min[TEST_FINSH]=headL1min->site;
//						MID.max[TEST_FINSH]=headMidmax->site;MID.min[TEST_FINSH]=headMidmin->site;
				//释放链表，（并存储链表平均值）
				freeLinkedList(&headR2max,R2.max_average+TEST_FINSH);freeLinkedList(&headR2min,R2.min_average+TEST_FINSH);
				freeLinkedList(&headL2max,L2.max_average+TEST_FINSH);freeLinkedList(&headL2min,L2.min_average+TEST_FINSH);		
				freeLinkedList(&headR1max,R1.max_average+TEST_FINSH);freeLinkedList(&headR1min,R1.min_average+TEST_FINSH);
				freeLinkedList(&headL1max,L1.max_average+TEST_FINSH);freeLinkedList(&headL1min,L1.min_average+TEST_FINSH);
				freeLinkedList(&headMidmax,MID.max_average+TEST_FINSH);freeLinkedList(&headMidmin,MID.min_average+TEST_FINSH);
				node_num[0]=0;node_num[1]=0;node_num[2]=0;node_num[3]=0;node_num[4]=0;//链表节点数量计数清零
				node_num[5]=0;node_num[6]=0;node_num[7]=0;node_num[8]=0;node_num[9]=0;
				*sim_cn+=1;
		}
		else//校准信息保存
		{
			if(TEST_FINSH==1)//两种颜色都采集完成
			{	
				printf("两种颜色采集完毕  \r\n");
				uint16_t *v;u8 *v2;
				v = (uint16_t*)malloc(5 * sizeof(uint16_t));
				v2 = (u8*)malloc(12 * sizeof(u8));
				u8 *datatemp;  //Flash读取缓存数组
				datatemp = (u8*)malloc(12 * sizeof(u8));
				v[0]=cua_cri(&L2);v[1]=cua_cri(&L1);
				v[2]=cua_cri(&MID);v[3]=cua_cri(&R1);v[4]=cua_cri(&R2);
				v2[0]=v[0]/16;v2[1]=v[0]%16;
				v2[2]=v[1]/16;v2[3]=v[1]%16;
				v2[4]=v[2]/16;v2[5]=v[2]%16;
				v2[6]=v[3]/16;v2[7]=v[3]%16;
				v2[8]=v[4]/16;v2[9]=v[4]%16;
				v2[10]=COMMUNICATION_MODE;v2[11]=COMMUNICATION_MODE;
				STMFLASH_Write(FLASH_USER_START_ADDR,(u16*)v2,sizeof(v2)+2);//PWM设定值写到FLAH
				//STMFLASH_Read(FLASH_USER_START_ADDR,(u16*)datatemp,sizeof(v2)+1);
//						printf("%d\r\t",datatemp[0]);printf("%d\r\n",datatemp[1]);
//						printf("%d\r\t",datatemp[2]);printf("%d\r\n",datatemp[3]);
//						printf("%d\r\t",datatemp[4]);printf("%d\r\n",datatemp[5]);
//						printf("%d\r\t",datatemp[6]);printf("%d\r\n",datatemp[7]);
//						printf("%d\r\t",datatemp[8]);printf("%d\r\n",datatemp[9]);
				printf("写入分界值=%d,%d,%d,%d,%d\r\n",v[0],v[1],v[2],v[3],v[4]);
				if(v2[10]==0)
				{
					printf("IIC模式");
				}
				else if(v2[10]==1)
				{
					printf("串口模式");
				}
				else
				{
					printf("模式设置错误");
				}
				free(v);free(v2);free(datatemp);
				v=NULL;v2=NULL;datatemp=NULL;
				free(node_num);node_num=NULL;
				free(sim_cn);sim_cn=NULL;
				//MODE_WORK=0;//切换为工作模式
				printf("校准完成\r\n");
				while(1)//校准完成
				{
					BSP_LED_On(LED_RED);
					HAL_Delay(50);
				}
			}
			else//采集第二种颜色
			{
				printf("第一种颜色采集完毕  \r\n");
				TEST_FINSH=1;
				BSP_LED_On(LED_RED);
				printf("请切换颜色\n");
				HAL_Delay(3000);
			}
			*sim_cn=0;
		}
  }
  if(Timer_50ms_Task==1)
  {
	Timer_50ms_Task=0;
	BSP_LED_Toggle(LED_RED);			  
  }
}

/*工作模式流程*/
static void M2(void)
{
//  if(Timer_5ms_Task==1)
//  {
//	Timer_5ms_Task=0;
	//MedianValueAverageFiltering((uint16_t *)adc_value);//数据加入滤波
	
	if(COMMUNICATION_MODE == IIC)//--------------------!!!!!!!!!!!!!!!调试完改成==
	{				
		APP_SlaveTransmit_DMA((uint8_t *)ans, 6);
//		/* 等待主机发送数据完成 */
		while (State_IIC != I2C_STATE_READY)
		{
		}
		if(Timer_2ms_Task==1)
		{
			Timer_2ms_Task=0;
			for(uint8_t i=0;i<5;i++)
			{
			   ans[i]=compare(i);
			}
			
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, ans[0]);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, ans[1]);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, ans[2]);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, ans[3]);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, ans[4]);
		}
//		#ifdef IIC_sf
//		//地址校验
//		 while (!IIC_CheckStart());//检测开始信号
//		 address = IIC_Addr_RW();	 
//		 MyIIC_SendAck(1);
//		 if ((addr&0xFE) == 0xA0) 
//		 {
//			// 主机请求从机发送数据
//			//uint8_t dataToSend = 0x55; // 想要发送的数据
//			// 从机向主机发送数据
//			IIC_SendByte(0x55);
//			// 等待主机的 ACK
//			if (MyIIC_ReceiveAck()) {
//				// 主机确认接收数据
//			} else {
//				// 主机拒绝接收数据或发生错误
//			}
//			while (!IIC_CheckStop());
//		}
//		#endif
	}
	else//串口通信
	{
		if(Timer_2KHZ_Task==1)
		{
			Timer_2KHZ_Task=0;
			for(uint8_t i=0;i<5;i++)
			{
			   ans[i]=compare(i);
			}
			HAL_UART_Transmit_IT(&DebugUartHandle, (uint8_t*)ans, sizeof(ans));
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, ans[0]);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, ans[1]);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, ans[2]);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, ans[3]);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, ans[4]);
		}
	}						
}
/**
  * @brief  系统时钟配置函数
  * @param  无
  * @retval 无
  */ 
static void APP_SystemClockConfig(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE | RCC_OSCILLATORTYPE_HSI \
                                   | RCC_OSCILLATORTYPE_LSI | RCC_OSCILLATORTYPE_LSE;  /* 配置HSE、HSI、LSI、LSE */
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;                                             /* 开启HSI */
  RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV1;                                             /* HSI不分频 */
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_24MHz;                     /* HSI校准频率24MHz */
  RCC_OscInitStruct.HSEState = RCC_HSE_OFF;                                            /* 关闭HSE */
  /* RCC_OscInitStruct.HSEFreq = RCC_HSE_16_32MHz; */                                  /* HSE频率范围16~32MHz */
  RCC_OscInitStruct.LSIState = RCC_LSI_OFF;                                            /* 关闭LSI */
  RCC_OscInitStruct.LSEState = RCC_LSE_OFF;                                            /* 关闭LSE */
  /* RCC_OscInitStruct.LSEDriver = RCC_LSEDRIVE_MEDIUM; */                             /* 默认LSE驱动能力 */
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_OFF;                                        /* 关闭PLL */
  /* RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_NONE; */                          /* PLL无时钟源 */
  /* 配置振荡器 */
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1;/* 配置SYSCLK、HCLK、PCLK */
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;                                        /* 配置系统时钟为HSI */
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;                                            /* AHB时钟不分频 */
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;  
  /* 配置时钟源 */
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}
/**
  * @brief  错误执行函数
  * @param  无
  * @retval 无
  */
void Error_Handler(void)
{
  /* 无限循环 */
  while (1)
  {
	  
  }
}



.\output\debug\iic_software.o: ..\MYBSP\IIC_software\iic_software.c

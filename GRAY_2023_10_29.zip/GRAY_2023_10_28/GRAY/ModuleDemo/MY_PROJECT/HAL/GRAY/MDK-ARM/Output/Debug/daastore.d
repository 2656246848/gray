.\output\debug\daastore.o: ..\MYBSP\DataStore\daastore.c

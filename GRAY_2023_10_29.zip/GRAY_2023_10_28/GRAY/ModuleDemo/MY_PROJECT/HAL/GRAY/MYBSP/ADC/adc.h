#ifndef __ADC_H__
#define __ADC_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

void APP_AdcConfig(void);
extern ADC_HandleTypeDef 			  AdcHandle;
extern volatile uint16_t adc_value[5];
extern volatile uint16_t average_value[5];//adc滤波后
void ADC_sampling();

#ifdef __cplusplus
}
#endif

#endif /* __ADC_H__ */


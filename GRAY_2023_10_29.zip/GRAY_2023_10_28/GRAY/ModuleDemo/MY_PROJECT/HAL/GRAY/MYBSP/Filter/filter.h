#ifndef __FILTER_H__
#define __FILTER_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"
void MedianValueAverageFiltering(uint16_t *adc_sample_add);
	
#ifdef __cplusplus
}
#endif

#endif /* __TIM_H__ */
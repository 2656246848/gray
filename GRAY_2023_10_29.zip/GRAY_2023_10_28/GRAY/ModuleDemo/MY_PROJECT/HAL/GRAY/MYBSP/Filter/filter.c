#include "filter.h"
#include "adc.h"

// 定义循环队列结构
#define QUEUE_SIZE 3 // 队列的大小
uint16_t *ap = average_value;
uint16_t adcQueue0[QUEUE_SIZE];
uint16_t adcQueue1[QUEUE_SIZE];
uint16_t adcQueue2[QUEUE_SIZE];
uint16_t adcQueue3[QUEUE_SIZE];
uint16_t adcQueue4[QUEUE_SIZE];
static uint16_t sum[5]= {0,0,0,0,0};
static char front = 0;//当队列第一次写满后，后面的循环中front总是在rear后面一位
static char rear = 0;//写入位置索引

// 将新的ADC样本添加到队列中
void addToQueue(uint16_t *adc_sample_add) {
    adcQueue0[rear] = *adc_sample_add;
	adcQueue1[rear] = *(adc_sample_add+1);
	adcQueue2[rear] = *(adc_sample_add+2);
	adcQueue3[rear] = *(adc_sample_add+3);
	adcQueue4[rear] = *(adc_sample_add+4);
    rear = (rear + 1) % QUEUE_SIZE; // 更新队列索引
    if (rear == front) {
        front = (front + 1) % QUEUE_SIZE; // 如果队列满，更新队列头部索引
    }
}

// 计算队列中样本的平均值
void calculateAverage(uint16_t *adc_sample_add) {

    char count = 0;
    char i = front;
    
    // 遍历队列并计算总和
    while (i != rear) {
        sum[0]+= adcQueue0[i];
		sum[1]+= adcQueue1[i];
		sum[2]+= adcQueue2[i];
		sum[3]+= adcQueue3[i];
		sum[4]+= adcQueue4[i];
        count++;
        i = (i + 1) % QUEUE_SIZE;
    }
	if (count > 0) {
		for (int j = 0; j < 5; j++) {
			ap[j] = sum[j] / count;
		}
	} 
	else {
		for (int j = 0; j < 5; j++) {
			ap[j] = adc_sample_add[j];
		}
	}
	for (int j = 0; j < 5; j++) {
			sum[j] = 0;
	}
}

////adc采样滤波器
void MedianValueAverageFiltering(uint16_t *adc_sample_add)
{
	addToQueue(adc_sample_add);
	calculateAverage(adc_sample_add);
	
}
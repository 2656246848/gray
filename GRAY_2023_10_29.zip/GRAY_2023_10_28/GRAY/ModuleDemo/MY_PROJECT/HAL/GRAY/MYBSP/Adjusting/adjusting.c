#include "adjusting.h"

//uint8_t node_num[10]={0,0,0,0,0,0,0,0,0,0};//10个链表节点数量
const static uint8_t LIST_LENGTH = 4;//链表最大长度
uint8_t count=0;//计数

// 插入新值到单向链表中，保持升序排序，保留最小20个节点
void insertSorted_min(struct Node **head, uint16_t value,char num) //head是指向头节点指针的指针
{
    // 创建新节点并分配内存
    struct Node *newNode = (struct Node *)malloc(sizeof(struct Node));
    newNode->site = value;
    newNode->next = NULL;

    // 如果链表为空或者新值小于等于头节点的值
    if (*head == NULL || value <= (*head)->site) 
	{
        // 将新节点插入到链表头部
        newNode->next = *head;//新节点的next指针指向原头结点，即创建新的链表头
        *head = newNode;//将链表头指针 *head 更新为指向新创建的节点 newNode
		node_num[num]++;
    } 
	else 
	{
        // 否则，遍历链表找到插入位置
        struct Node *current = *head;//初始化current为头结点指针，最后一个节点的next指针指向NULL
        while (current->next != NULL && current->next->site < value)
		{
			current = current->next;
		}
		if(current->next!=NULL)//可以插入
		{
			node_num[num]++;
			// 插入新节点到合适位置
			newNode->next = current->next;//新节点next指针指向比value大的那个节点
			current->next = newNode;//比value大的节点next指针指向新节点
		}
		else
		{
			free(newNode);
		}        	
	}
	if(node_num[num]>LIST_LENGTH)//删除最后一个节点
	{
		struct Node *linshi = *head;
		struct Node *last = *head;
		while(linshi->next!=NULL)
		{
			last=linshi;
			linshi=linshi->next;
		}		
		free(linshi);
		linshi=NULL;
		last->next=NULL;
		node_num[num]--;
	}	
}

// 插入新值到单向链表中，保持降序排序，保留最大20个节点
void insertSorted_max(struct Node **head, uint16_t value,char num) //head是指向头节点指针的指针
{
    // 创建新节点并分配内存
    struct Node *newNode = (struct Node *)malloc(sizeof(struct Node));
    newNode->site = value;
    newNode->next = NULL;

    // 如果链表为空或者新值大于等于头节点的值
    if (*head == NULL || value >= (*head)->site) 
	{
        // 将新节点插入到链表头部
        newNode->next = *head;//新节点的next指针指向原头结点，即创建新的链表头
        *head = newNode;//将链表头指针 *head 更新为指向新创建的节点 newNode
		//usb_printf("add_head： %hx  \r\n", newNode->site);//测试
		node_num[num]++;
    } 
	else 
	{
        // 否则，遍历链表找到插入位置
        struct Node *current = *head;//初始化current为头结点指针，最后一个节点的next指针指向NULL
        while (current->next != NULL && current->next->site > value)
		{
			current = current->next;
		}
		if(current->next!=NULL)//可以插入
		{
			node_num[num]++;
			// 插入新节点到合适位置
			//usb_printf("add_mid： %hx  \r\n", newNode->site);//测试
			newNode->next = current->next;//新节点next指针指向比value小的那个节点
			current->next = newNode;//比value大的节点next指针指向新节点
		}
		else
		{
			free(newNode);
		}
        	
	}
	if(node_num[num]>LIST_LENGTH)//删除最后一个节点
	{
		struct Node *linshi = *head;
		struct Node *last = *head;
		while(linshi->next!=NULL)
		{
			last=linshi;
			linshi=linshi->next;
		}	
		//usb_printf("remove： %hx  \r\n", linshi->site);//测试		
		free(linshi);
		linshi=NULL;
		last->next=NULL;
		node_num[num]--;
	}		
}

//求绝对值
uint16_t absolute(int16_t number) {
    return (number < 0) ? -number : number;
}

//求数组中最大数的索引
uint8_t findMaxIndex(uint16_t array[], uint8_t length) {
    if (length <= 0) {
        // 处理空列表或无效输入的情况
        return -1; // 或者可以根据实际需求返回其他值
    }
    int maxIndex = 0; // 假设第一个元素是最大的
    int maxValue = array[0];

    for (int i = 1; i < length; i++) {
        if (array[i] > maxValue) {
            maxValue = array[i];
            maxIndex = i;
        }
    }
    return maxIndex;
}

////释放链表内存并计算链表内site平均值
//uint16_t freeLinkedList(struct Node **head) {
//    struct Node *current = *head;
//    struct Node *next;
//	uint16_t sum = 0;

//    while (current != NULL) {
//		sum+=current->site;
//        next = current->next; // 保存下一个节点的指针
//        free(current); // 释放当前节点的内存
//        current = next; // 移动到下一个节点
//    }
//	sum/=LIST_LENGTH;
//    *head = NULL; // 将链表头指针设置为 NULL，表示链表已被释放
//	return sum;
//}
void freeLinkedList(struct Node **head,uint32_t * sh) {
    struct Node *current = *head;
    struct Node *next;
	uint8_t list_length=0;
    while (current != NULL) {
		*sh+=current->site;
        next = current->next; // 保存下一个节点的指针
        free(current); // 释放当前节点的内存
        current = next; // 移动到下一个节点
		list_length++;
    }
	//printf(" Listlength=%d\r\t", list_length);
	*sh/=list_length;
    *head = NULL; // 将链表头指针设置为 NULL，表示链表已被释
}
//void freeLinkedList(struct Node **head) {
//    struct Node *current = *head;
//    struct Node *next;

//    while (current != NULL) {
//        next = current->next; // 保存下一个节点的指针
//        free(current); // 释放当前节点的内存
//        current = next; // 移动到下一个节点
//    }
//    *head = NULL; // 将链表头指针设置为 NULL，表示链表已被释
//}

void print_list(struct Node **head)
{	
	count=0;
	struct Node *current = *head;
	while(current != NULL)
	{
		printf(" List[%d]:%hx\r\t", count,(current->site));
		count++;
		current = current->next;
	}	
	printf(" 链表长度:%d\r\n",count);
	
}

//求颜色分界值
uint16_t cua_cri(TESTDATA* p1)
{
//	double pil = 0.5;double max_pil = 0.5;double min_pil = 0.5;double pil_set=0.5;
//	if(absolute((int16_t)(p1->max_average[1] - p1->min_average[0])) > absolute((int16_t)(p1->max_average[0]-p1->min_average[1])))
//	{
//		pil =(p1->max_average[1]-p1->min_average[0])/4095;//区间范围越大，阈值也往大了设
//		pil_set =  (pil < min_pil) ? min_pil : (pil > max_pil) ? max_pil : pil;      //限制在min~max
//		if(p1->min_average[1]>p1->max_average[0])
//		{
//			printf("%d - (%d - %d)* pil_set\r\n",p1->min_average[1],p1->min_average[1],p1->max_average[0]);
//			return (uint16_t)(p1->min_average[1]-(p1->min_average[1]-p1->max_average[0])*pil_set);
//		}
//		else
//		{
//			printf("%d - (%d - %d)* pil_set\r\n",p1->max_average[0],p1->max_average[0],p1->min_average[1]);
//			return (uint16_t)(p1->max_average[0]-(p1->max_average[0]-p1->min_average[1])*pil_set);
//		}
//			
//	}
//	else{
//		pil =(p1->max_average[0]-p1->min_average[1])/4095;
//		pil_set =  (pil < min_pil) ? min_pil : (pil > max_pil) ? max_pil : pil;
//		if(p1->min_average[0]>p1->max_average[1])
//		{
//			printf("%d - (%d - %d)* pil_set\r\n",p1->min_average[0],p1->min_average[0],p1->max_average[1]);
//			return (uint16_t)(p1->min_average[0]-(p1->min_average[0]-p1->max_average[1])*pil_set);
//		}
//		else
//		{
//			printf("%d - (%d - %d)* pil_set\r\n",p1->max_average[1],p1->min_average[0],p1->max_average[1]);
//			return (uint16_t)(p1->max_average[1]-(p1->max_average[1]-p1->min_average[0])*pil_set);
//		}
//		
//	}

	double pil = 0.5;double max_pil = 0.6;double min_pil = 0.4;double pil_set=0.5;
	if(absolute((int16_t)(p1->max_average[1] - p1->min_average[0])) > absolute((int16_t)(p1->max_average[0]-p1->min_average[1])))
	{
		pil =(p1->max_average[1]-p1->min_average[0])/4095;//区间范围越大，阈值也往大了设
		pil_set =  (pil < min_pil) ? min_pil : (pil > max_pil) ? max_pil : pil;      //限制在min~max
		if(p1->min_average[1]>p1->max_average[0])
		{
			printf("%d + (%d - %d)* pil_set\r\n",p1->max_average[0],p1->min_average[1],p1->max_average[0]);
			return (uint16_t)(p1->max_average[0]+(p1->min_average[1]-p1->max_average[0])*pil_set);
		}
		else
		{
			printf("%d + (%d - %d)* pil_set\r\n",p1->min_average[1],p1->max_average[0],p1->min_average[1]);
			printf("!!!!!!!!!!!!!!!!!!!!!!");
			return (uint16_t)(p1->min_average[1]+(p1->max_average[0]-p1->min_average[1])*pil_set);
		}
			
	}
	else{
		pil =(p1->max_average[0]-p1->min_average[1])/4095;
		pil_set =  (pil < min_pil) ? min_pil : (pil > max_pil) ? max_pil : pil;
		if(p1->min_average[0]>p1->max_average[1])
		{
			printf("%d + (%d - %d)* pil_set\r\n",p1->max_average[1],p1->min_average[0],p1->max_average[1]);
			return (uint16_t)(p1->max_average[1]+(p1->min_average[0]-p1->max_average[1])*pil_set);
		}
		else
		{
			printf("%d + (%d - %d)* pil_set\r\n",p1->min_average[0],p1->max_average[1],p1->min_average[0]);
			printf("!!!!!!!!!!!!!!!!!!!!!!");
			return (uint16_t)(p1->min_average[0]+(p1->max_average[1]-p1->min_average[0])*pil_set);
		}
	}
}

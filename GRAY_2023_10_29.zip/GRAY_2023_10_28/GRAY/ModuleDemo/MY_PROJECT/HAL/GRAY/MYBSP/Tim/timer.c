#include "timer.h"
#include "adc.h"
//uint16_t Timer_1ms_Task;
uint8_t Timer_2ms_Task;
uint8_t Timer_5ms_Task;
//uint16_t Timer_10ms_Task;
uint16_t Timer_50ms_Task;
uint16_t Timer_100ms_Task;
uint8_t Timer_1s_Task;
//uint8_t Timer_3s_Task;
uint8_t Timer_2KHZ_Task;
//uint8_t Tsc=0;
//volatile uint32_t TIM14_Cnt1 = 0;// 全局变量，用于存储毫秒级计数倿
volatile uint32_t TIM3_Cnt1 = 0;// 全局变量，用于存储毫秒级计数倿

TIM_HandleTypeDef    Tim3;//ledPWM管理定时器（20KHZ）
//TIM_HandleTypeDef    Tim14;//系统运行时间管理定时器

//void MX_TIM14_Init(void)
//{
//  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
//  TIM_MasterConfigTypeDef sMasterConfig = {0};
//  Tim14.Instance = TIM14;
//  Tim14.Init.Prescaler = 24-1;
//  Tim14.Init.CounterMode = TIM_COUNTERMODE_UP;
//  Tim14.Init.Period = 1000-1;
//  Tim14.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
//  Tim14.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
//  if (HAL_TIM_Base_Init(&Tim14) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
//  if (HAL_TIM_ConfigClockSource(&Tim14, &sClockSourceConfig) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
//  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
//  if (HAL_TIMEx_MasterConfigSynchronization(&Tim14, &sMasterConfig) != HAL_OK)
//  {
//    Error_Handler();
//  }
//}
void MX_TIM3_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  Tim3.Instance = TIM3;
  Tim3.Init.Prescaler = 12-1;
  Tim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  Tim3.Init.Period = 1000-1;
  Tim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  Tim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&Tim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&Tim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&Tim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&Tim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
//  sConfigOC.OCMode = TIM_OCMODE_PWM1;
//  sConfigOC.Pulse = 0;
//  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
//  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
//  if (HAL_TIM_PWM_ConfigChannel(&Tim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
//  {
//    Error_Handler();
//  }
  //HAL_TIM_MspPostInit(&Tim3);

}

/**
  * @brief 初始TIM14相关MSP
  */
void HAL_TIM_Base_MspInit(TIM_HandleTypeDef *htim)
{
//  if(htim->Instance==TIM14)
//  {
//	  /* 使能TIM14时钟 */
//	  __HAL_RCC_TIM14_CLK_ENABLE();
//	  
//	  /* 设置中断优先级 */
//	  HAL_NVIC_SetPriority(TIM14_IRQn, 0, 0);
//	  /* 使能TIM14中断 */
//	  HAL_NVIC_EnableIRQ(TIM14_IRQn);
//	  HAL_TIM_Base_Start_IT(&Tim14);
//  }
  if(htim->Instance==TIM3)
  {
	/* 使能TIM3时钟 */
	  __HAL_RCC_TIM3_CLK_ENABLE();
	  
	  /* 设置中断优先级 */
	  HAL_NVIC_SetPriority(TIM3_IRQn, 2, 2);
	  /* 使能TIM3中断 */
	  HAL_NVIC_EnableIRQ(TIM3_IRQn);
	  HAL_TIM_Base_Start_IT(&Tim3);
  }
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{	
	// 判断是定时器14发生的中断
	if(htim->Instance == TIM3)
	{
		Timer_2KHZ_Task=1;
		TIM3_Cnt1 ++;
		ADC_sampling();//adc采集
		if(TIM3_Cnt1%4==0)
		{ 
			Timer_2ms_Task=1;
		}		
		if(TIM3_Cnt1%10==0)
		{ 
			Timer_5ms_Task=1;
		}
//		if(TIM3_Cnt1%20==0)
//			Timer_10ms_Task=1;
		if(TIM3_Cnt1%100==0)
		{
			Timer_50ms_Task=1;
//			for(uint8_t i=0;i<5;i++)
//			{
//			   ans[i]=compare(i);
//			}	
		}
		if(TIM3_Cnt1%200==0)
		{
			Timer_100ms_Task=1;
			if(!MODE_WORK)
			{
				if(COMMUNICATION_MODE!= 0x00)//串口模式1.5s闪亮1次
				{  
					  if(task_count%15==0)
					  {
							BSP_LED_Off(LED_RED);
							task_count++;				  
					  }
					  else if(task_count%16==0)
					  {
						  BSP_LED_On(LED_RED);
						  task_count=1;
					  }
					  else
					  {
						BSP_LED_On(LED_RED);
						  task_count++;
					  }
				 }
				 else//IIC1.5s闪亮2次
				 {
					 if(task_count%13==0)
					  {
							BSP_LED_Off(LED_RED);
							task_count++;				  
					  }
					  else if(task_count%14==0)
					  {
						  BSP_LED_On(LED_RED);
						  task_count++;
					  }
					  else if(task_count%15==0)
					  {
							BSP_LED_Off(LED_RED);
							task_count++;				  
					  }
					  else if(task_count%16==0)
					  {
							BSP_LED_On(LED_RED);
							task_count=1;				  
					  }
					  else
					  {
							BSP_LED_On(LED_RED);
							task_count++;
					  }
				  }
				  if(task_count>=60000) task_count=0;	
			  }
	    }			
		if(TIM3_Cnt1%2000==0)
		{
			Timer_1s_Task=1;
	    }
//		if(TIM3_Cnt1%6000==0)
//		{
//			Timer_3s_Task=1;			
//		}
		if(TIM3_Cnt1>=8000000) TIM3_Cnt1=0;
		
	}
}
///* USER CODE END 1 */

#ifndef __TIM_H__
#define __TIM_H__

#ifdef __cplusplus
extern "C" {
#endif


#include "main.h"

#include "stdio.h"
//extern TIM_HandleTypeDef htim14;
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim);
//extern uint16_t Timer_1ms_Task;
extern uint8_t Timer_2ms_Task;
extern uint8_t Timer_5ms_Task;
//extern uint16_t Timer_10ms_Task;
extern uint16_t Timer_50ms_Task;
extern uint16_t Timer_100ms_Task;
extern uint8_t Timer_1s_Task;
//extern uint8_t Timer_3s_Task;
extern uint8_t Timer_2KHZ_Task;
extern volatile uint32_t TIM3_Cnt1;
//extern volatile uint32_t TIM14_Cnt1;// 全局变量，用于存储毫秒级计数倿
//void MedianValueAverageFiltering(uint16_t *adc_sample_add);


//extern TIM_HandleTypeDef htim14;
//extern TIM_HandleTypeDef htim3;
//extern TIM_HandleTypeDef    Tim14;
extern TIM_HandleTypeDef    Tim3;
//void MX_TIM14_Init(void);
void MX_TIM3_Init(void);
void HAL_TIM_Base_MspInit(TIM_HandleTypeDef *htim);
//void MX_TIM3_Init(void);

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);



#ifdef __cplusplus
}
#endif

#endif /* __TIM_H__ */


#include "adc.h"

volatile uint16_t adc_value[5];//adc原始数据
volatile uint16_t average_value[5];//adc滤波后

ADC_HandleTypeDef 			  AdcHandle;

void APP_AdcConfig(void)
{  
  __HAL_RCC_ADC_FORCE_RESET();
  __HAL_RCC_ADC_RELEASE_RESET();
  __HAL_RCC_ADC_CLK_ENABLE();                                                     /* 使能ADC时钟 */

  ADC_ChannelConfTypeDef        sConfig = {0};
  AdcHandle.Instance = ADC1;
  
  /* ADC校准 */
  if (HAL_ADCEx_Calibration_Start(&AdcHandle) != HAL_OK)                          
  {
    Error_Handler();
  }
  
  AdcHandle.Instance                   = ADC1;                                    /* ADC1 */
  AdcHandle.Init.ClockPrescaler        = ADC_CLOCK_SYNC_PCLK_DIV1;                /* 设置ADC时钟 */
  AdcHandle.Init.Resolution            = ADC_RESOLUTION_12B;                      /* 转换分辨率12bit */
  AdcHandle.Init.DataAlign             = ADC_DATAALIGN_RIGHT;                     /* 数据右对齐 */
  AdcHandle.Init.ScanConvMode          = ADC_SCAN_DIRECTION_FORWARD;             /* 扫描序列方向：向下 */
  AdcHandle.Init.EOCSelection          = ADC_EOC_SINGLE_CONV;                     /* 单次采样 */
  AdcHandle.Init.LowPowerAutoWait      = ENABLE;                                  /* 等待转换模式开启 */
  AdcHandle.Init.ContinuousConvMode    = DISABLE;                                  /* 连续转换模式 */
  AdcHandle.Init.DiscontinuousConvMode = DISABLE;                                 /* 不使能非连续模式 */
  AdcHandle.Init.ExternalTrigConv      = ADC_SOFTWARE_START;                      /* 软件触发 */
  AdcHandle.Init.ExternalTrigConvEdge  = ADC_EXTERNALTRIGCONVEDGE_NONE;           /* 触发边沿无 */
  AdcHandle.Init.DMAContinuousRequests = DISABLE;                                  /* DMA不使能 */
  AdcHandle.Init.Overrun               = ADC_OVR_DATA_OVERWRITTEN;                /* 当过载发生时，覆盖上一个值 */
  AdcHandle.Init.SamplingTimeCommon    = ADC_SAMPLETIME_239CYCLES_5;              /* 通道采样时间为239.5ADC时钟周期 */

  /* ADC初始化 */
  if (HAL_ADC_Init(&AdcHandle) != HAL_OK)                                        
  {
    Error_Handler();
  }

  sConfig.Channel      = ADC_CHANNEL_0;
  //sConfig.Rank         = ADC_RANK_CHANNEL_NUMBER;
  sConfig.Rank = 1; // 通道的排名，第一个采样的通道
  /* 通道0配置 */
  if (HAL_ADC_ConfigChannel(&AdcHandle, &sConfig) != HAL_OK)                      
  {
    Error_Handler();
  }
  
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 2; 
  if (HAL_ADC_ConfigChannel(&AdcHandle, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  sConfig.Channel = ADC_CHANNEL_2;
  sConfig.Rank = 3;
  if (HAL_ADC_ConfigChannel(&AdcHandle, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  sConfig.Channel = ADC_CHANNEL_3;
  sConfig.Rank = 4; 
  if (HAL_ADC_ConfigChannel(&AdcHandle, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = 5;
  if (HAL_ADC_ConfigChannel(&AdcHandle, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief 初始化ADC相关MSP
  */
void HAL_ADC_MspInit(ADC_HandleTypeDef *hadc)
{
  GPIO_InitTypeDef          GPIO_InitStruct = {0};;
  __HAL_RCC_SYSCFG_CLK_ENABLE();                              /* SYSCFG时钟使能 */
  //__HAL_RCC_DMA_CLK_ENABLE();                                 /* DMA时钟使能 */
  __HAL_RCC_GPIOA_CLK_ENABLE();                               /* 使能GPIOA时钟 */
 
  /* ---------------- */
  //    /**ADC1 GPIO Configuration
//    PA1     ------> ADC1_IN1
//    PA2     ------> ADC1_IN2
//    PA3     ------> ADC1_IN3
//    PA4     ------> ADC1_IN4
//    PA0     ------> ADC1_IN0
  /* ---------------- */
  GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

/*adc采集并打印信息*/
void ADC_sampling()
{
	/* ADC开启 */
	HAL_ADC_Start(&AdcHandle);
	for (uint8_t i = 0; i < 5; i++)
	{
	  /* 等待ADC转换 */
	  HAL_ADC_PollForConversion(&AdcHandle, 10);
	  /* 获取AD值 */
	  adc_value[i] = HAL_ADC_GetValue(&AdcHandle);
	}
  
}
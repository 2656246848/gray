#ifndef __IIC_LL_H__
#define __IIC_LL_H__

#ifdef __cplusplus
extern "C" {
#endif

///* Includes ------------------------------------------------------------------*/
#include "main.h"

#ifdef IIC_LL
/* Private define ------------------------------------------------------------*/
#define I2C_ADDRESS        0xA0     /* 本机/从机地址 */
#define I2C_SPEEDCLOCK     100000   /* 通讯速度100K */
#define I2C_STATE_READY    0        /* 就绪状态 */
#define I2C_STATE_BUSY_TX  1        /* 发送状态 */
#define I2C_STATE_BUSY_RX  2        /* 接收状态 */

extern uint8_t         *pBuffPtr ;
extern __IO uint16_t   XferCount;
//extern __IO uint32_t   Devaddress;
extern __IO uint32_t   State_IIC;

//extern I2C_HandleTypeDef I2cHandle;
//extern uint8_t aTxBuffer[5];
////extern uint8_t aRxBuffer[5];

//void My_IIC_INIT();
//void IIC_send_DMA(uint16_t DevAddress, uint8_t *pData, uint16_t Size);
//void IIC_recieve_DMA( uint16_t DevAddress, uint8_t *pData, uint16_t Size);
void APP_SlaveTransmit_DMA(uint8_t *pData, uint16_t Size);
void APP_ConfigI2cSlave_LL(void);
void APP_DmaIRQCallback(void);
void APP_SlaveIRQCallback_NACK(void);
void APP_SlaveIRQCallback(void);
#endif
#ifdef __cplusplus
}
#endif

#endif /* __ADC_H__ */
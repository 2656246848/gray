#ifndef __DATASTORE_H__
#define __DATASTORE_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"
//=========================数据类型宏定义
#define u8 uint8_t
#define u16 uint16_t
#define u32 uint32_t
#define __IO    volatile 
typedef __IO uint16_t vu16;

#define FLASH_TYPEPROGRAM_HALFWORD             0x01U  /*!<Program a half-word (16-bit) at a specified address.*/
#define FLASH_TYPEPROGRAM_WORD                 0x02U  /*!<Program a word (32-bit) at a specified address.*/
#define FLASH_TYPEPROGRAM_DOUBLEWORD           0x03U  /*!<Program a double word (64-bit) at a specified address*/
#define STM32_FLASH_BASE    0x08000000 		//STM32 FLASH的起始地址
#define STM32_FLASH_SIZE 	32	 	//所选STM32的FLASH容量大小(单位为K)
#define STM_SECTOR_SIZE     1024    //1K字节

#define FLASH_USER_START_ADDR 0x08007000//写入地址起始位置

void STMFLASH_Write(u32 WriteAddr,u16 *pBuffer,u16 NumToWrite);//写
void STMFLASH_Read(u32 ReadAddr,u16 *pBuffer,u16 NumToRead);//读
//extern uint8_t node_num[10];
#ifdef __cplusplus
}
#endif

#endif /* __TIM_H__ */
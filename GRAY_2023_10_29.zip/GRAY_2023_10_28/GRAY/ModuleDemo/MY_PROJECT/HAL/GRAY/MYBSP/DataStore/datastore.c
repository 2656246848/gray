#include "datastore.h"
/**
 * @brief  擦除FLASH
 * @param  无
 * @retval 无
 */
static void APP_FlashErase(uint32_t WriteAddr)
{
  uint32_t SECTORError = 0;
  FLASH_EraseInitTypeDef EraseInitStruct;

  EraseInitStruct.TypeErase = FLASH_TYPEERASE_SECTORERASE;         /* 擦写类型FLASH_TYPEERASE_PAGEERASE=Page擦, FLASH_TYPEERASE_SECTORERASE=Sector擦 */
  EraseInitStruct.SectorAddress = WriteAddr;           /* 擦写起始地址  */
  EraseInitStruct.NbSectors = 1;                                   /* 需要擦写的扇区数量  */
  if (HAL_FLASHEx_Erase(&EraseInitStruct, &SECTORError) != HAL_OK) /* 执行sector擦除,SECTORError返回擦写错误的sector,返回0xFFFFFFFF,表示擦写成功  */
  {
    Error_Handler();
  }
}

//static void APP_FlashErase(uint32_t WriteAddr)
//{
//  uint32_t PAGEError = 0;
//  FLASH_EraseInitTypeDef EraseInitStruct;

//  EraseInitStruct.TypeErase = FLASH_TYPEERASE_PAGEERASE;         /* 擦写类型FLASH_TYPEERASE_PAGEERASE=Page擦, FLASH_TYPEERASE_SECTORERASE=Sector擦 */
//  EraseInitStruct.PageAddress = WriteAddr;           /* 擦写起始地址 */
//  EraseInitStruct.NbPages = 1;      /* 需要擦写的页数量 */
//  if (HAL_FLASHEx_Erase(&EraseInitStruct, &PAGEError) != HAL_OK) /* 执行page擦除,PAGEError返回擦写错误的page,返回0xFFFFFFFF,表示擦写成功 */
//  {
//    Error_Handler();
//  }
//}

/**
 * @brief  查空FLASH
 * @param  无
 * @retval 无
 */
//static void APP_FlashBlank(uint32_t WriteAddr,uint16_t length)
//{
//  uint32_t addr = 0;

//  while (addr < length)
//  {
//    if (0xFFFFFFFF != HW32_REG(WriteAddr + addr))
//    {
//      Error_Handler();
//    }
//    addr += 4;
//  }
//}

static void Flash_PageErase(uint32_t PageAddress)
{
  uint32_t SECTORError = 0;
  FLASH_EraseInitTypeDef EraseInitStruct;

  EraseInitStruct.TypeErase = FLASH_TYPEERASE_SECTORERASE;         /* 擦写类型FLASH_TYPEERASE_PAGEERASE=Page擦, FLASH_TYPEERASE_SECTORERASE=Sector擦 */
  EraseInitStruct.SectorAddress = PageAddress;           /* 擦写起始地址  */
  EraseInitStruct.NbSectors = 1;                                   /* 需要擦写的扇区数量  */
  if (HAL_FLASHEx_Erase(&EraseInitStruct, &SECTORError) != HAL_OK) /* 执行sector擦除,SECTORError返回擦写错误的sector,返回0xFFFFFFFF,表示擦写成功  */
  {
    Error_Handler();
  }
}

/**
 * @brief  写入FLASH
 * @param  无
 * @retval 无
 */
static void APP_FlashProgram(u32 WriteAddr,u16 *pBuffer)
{
  uint32_t flash_program_start = WriteAddr;                /* flash写起始地址 */
  uint32_t flash_program_end = (WriteAddr + sizeof(pBuffer)); /* flash写结束地址 */
  uint32_t *src = (uint32_t *)pBuffer;                                    /* 数组指针 */

  while (flash_program_start < flash_program_end)
  {
    if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_PAGE, flash_program_start, src) == HAL_OK) /* 执行Program */
    {
      flash_program_start += FLASH_PAGE_SIZE; /* flash起始指针指向第一个page */
      src += FLASH_PAGE_SIZE / 4;             /* 更新数据指针 */
    }
  }
}

///**
// * @brief  校验FLASH
// * @param  无
// * @retval 无
// */
//static void APP_FlashVerify(u32 WriteAddr,u16 *pBuffer)
//{
//  uint32_t addr = 0;

//  while (addr < sizeof(pBuffer))
//  {
//    if (pBuffer[addr / 4] != HW32_REG(WriteAddr + addr))
//    {
//      Error_Handler();
//    }
//    addr += 4;
//  }
//}


 /**********************************************************************************
  * 函数功能: 读取指定地址的半字(16位数据) 
* 输入参数: faddr：读地址,地址必须为2的倍数
  * 返 回 值: 对应数据
  * 说    明： 
  */
u16 STMFLASH_ReadHalfWord(u32 faddr)
{
	return *(vu16*)faddr; 
}
 /**********************************************************************************
  * 函数功能:从指定地址开始读出指定长度的数据
  * 输入参数:ReadAddr:起始地址、pBuffer:数据指针、NumToWrite:半字(16位)数
  * 返 回 值: 无
  * 说    明： 
  */
void STMFLASH_Read(u32 ReadAddr,u16 *pBuffer,u16 NumToRead)   	
{
	u16 i;
	for(i=0;i<NumToRead;i++)
	{
		pBuffer[i]=STMFLASH_ReadHalfWord(ReadAddr);//读取2个字节.
		ReadAddr+=2;//偏移2个字节.	
	}
}
 /**********************************************************************************
  * 函数功能:不检查的写入
  * 输入参数: WriteAddr:起始地址、pBuffer:数据指针、NumToWrite:半字(16位)数 
  * 返 回 值: 无
  * 说    明： 
  */
void STMFLASH_Write_NoCheck(u32 WriteAddr,u16 *pBuffer,u16 NumToWrite)   
{ 			 		 
	u16 i;
	for(i=0;i<NumToWrite;i++)
	{
		HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD,WriteAddr,(u32 *)pBuffer);
	    WriteAddr+=2;//地址增加2.
	}  
}
 /**********************************************************************************
  * 函数功能:从指定地址开始写入指定长度的数据
  * 输入参数:WriteAddr:起始地址(此地址必须为2的倍数!!)、pBuffer:数据指针、NumToWrite：半字(16位)数(就是要写入的16位数据的个数.)
  * 返 回 值: 无
  * 说    明： 
  */
void STMFLASH_Write(u32 WriteAddr,u16 *pBuffer,u16 NumToWrite)	
{
	u32 secpos;	   //扇区地址
	u16 secoff;	   //扇区内偏移地址(16位字计算)
	u16 secremain; //扇区内剩余地址(16位字计算)	   
 	u16 i;    
	u32 offaddr;   //去掉0X08000000后的地址
	u16 STMFLASH_BUF[STM_SECTOR_SIZE/2];    //缓存数组
	
	if(WriteAddr<STM32_FLASH_BASE||(WriteAddr>=(STM32_FLASH_BASE+1024*STM32_FLASH_SIZE)))return;//非法地址
	
	HAL_FLASH_Unlock();					    //解锁
	offaddr=WriteAddr-STM32_FLASH_BASE;		//实际偏移地址.
	secpos=offaddr/STM_SECTOR_SIZE;			//扇区地址  0~64 for STM32F103C8T6
	secoff=(offaddr%STM_SECTOR_SIZE)/2;		//在扇区内的偏移(2个字节为基本单位.)
	secremain=STM_SECTOR_SIZE/2-secoff;		//扇区剩余空间大小   
	if(NumToWrite<=secremain)secremain=NumToWrite;//不大于该扇区范围
	
	while(1) 
	{	
		
		Flash_PageErase(secpos*STM_SECTOR_SIZE+STM32_FLASH_BASE);	//擦除这个扇区
		FLASH_WaitForLastOperation(50000);            	//等待上次操作完成
		CLEAR_BIT(FLASH->CR, FLASH_CR_PER);							//清除CR寄存器的PER位，此操作应该在FLASH_PageErase()中完成！
		

		for(i=0;i<secremain;i++)//复制
		{
			STMFLASH_BUF[i+secoff]=pBuffer[i];	  
		}
		STMFLASH_Write_NoCheck(secpos*STM_SECTOR_SIZE+STM32_FLASH_BASE,STMFLASH_BUF,STM_SECTOR_SIZE/2);//写入整个扇区  
		
		if(NumToWrite==secremain)break;//写入结束了
		else//写入未结束
		{
			secpos++;				//扇区地址增1
			secoff=0;				//偏移位置为0 	 
		   	pBuffer+=secremain;  	//指针偏移
			WriteAddr+=secremain*2;	//写地址偏移(16位数据地址,需要*2)	   
		   	NumToWrite-=secremain;	//字节(16位)数递减
			if(NumToWrite>(STM_SECTOR_SIZE/2))secremain=STM_SECTOR_SIZE/2;//下一个扇区还是写不完
			else secremain=NumToWrite;//下一个扇区可以写完了
		}	 
	};	
	HAL_FLASH_Lock();		//上锁
}
 /**********************************************************************************
  * 函数功能:从指定地址开始写入指定长度的数据
  * 输入参数:WriteAddr:起始地址(此地址必须为2的倍数!!)、pBuffer:数据指针、NumToWrite：半字(16位)数(就是要写入的16位数据的个数.)
  * 返 回 值: 无
  * 说    明： 
  */
//void STMFLASH_Write(u32 WriteAddr,u16 *pBuffer,u16 NumToWrite)	
//{		
//	/* 解锁FLASH */
//	HAL_FLASH_Unlock();
//	
//	/* 擦除FLASH */
//	APP_FlashErase(WriteAddr);
//	
//    /* 查空FLASH */
//	APP_FlashBlank(WriteAddr,NumToWrite);
//	
//    /* 写FLASH */
//    APP_FlashProgram(WriteAddr,pBuffer);
//	
//	/* 锁定FLASH */
//    HAL_FLASH_Lock();
//	
//    /* 校验FLASH */
//   APP_FlashVerify(WriteAddr,pBuffer);
//	
//	HAL_FLASH_Lock();		//上锁
//}

 

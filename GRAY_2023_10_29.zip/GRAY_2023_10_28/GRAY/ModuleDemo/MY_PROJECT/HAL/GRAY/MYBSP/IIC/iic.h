#ifndef __IIC_H__
#define __IIC_H__

#ifdef __cplusplus
extern "C" {
#endif
#include "main.h"

#ifdef IIC_HAL
#define DARA_LENGTH      5                 /* 数据长度 */
#define I2C_ADDRESS      0xA0               /* 本机地址0xA0 */
#define I2C_SPEEDCLOCK   400000             /* 通讯速度100K */
#define I2C_DUTYCYCLE    I2C_DUTYCYCLE_16_9 /* 占空比 */

extern I2C_HandleTypeDef I2cHandle;
extern uint8_t aTxBuffer[5];
//extern uint8_t aRxBuffer[5];

void My_IIC_INIT();
void IIC_send_DMA(uint16_t DevAddress, uint8_t *pData, uint16_t Size);
void IIC_recieve_DMA( uint16_t DevAddress, uint8_t *pData, uint16_t Size);
#endif
#ifdef __cplusplus
}
#endif

#endif /* __ADC_H__ */
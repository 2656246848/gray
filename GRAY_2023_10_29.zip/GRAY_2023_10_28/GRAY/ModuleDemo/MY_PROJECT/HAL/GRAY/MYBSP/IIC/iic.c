#include "iic.h"
#ifdef IIC_HAL
I2C_HandleTypeDef I2cHandle;
//uint8_t aTxBuffer[5] = {1, 2, 3, 4, 5};
//uint8_t aRxBuffer[5] = {0, 0, 0, 0, 0};

static void APP_CheckEndOfTransfer(void);
static uint8_t APP_Buffercmp8(uint8_t* pBuffer1, uint8_t* pBuffer2, uint8_t BufferLength);
static void APP_LedBlinking(void);

void My_IIC_INIT()
{
	/* I2C初始化 */
  I2cHandle.Instance             = I2C;                      /* I2C */
  I2cHandle.Init.ClockSpeed      = I2C_SPEEDCLOCK;           /* I2C通讯速度 */
  I2cHandle.Init.DutyCycle       = I2C_DUTYCYCLE;            /* I2C占空比 */
  I2cHandle.Init.OwnAddress1     = I2C_ADDRESS;              /* I2C地址 */
  I2cHandle.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;  /* 禁止广播呼叫 */
  I2cHandle.Init.NoStretchMode   = I2C_NOSTRETCH_DISABLE;    /* 允许时钟延长 */
  if (HAL_I2C_Init(&I2cHandle) != HAL_OK)
  {
    Error_Handler();
  }
}

void IIC_send_DMA(uint16_t DevAddress, uint8_t *pData, uint16_t Size)
{
	/*判断当前I2C状态*/
	while (HAL_I2C_GetState(&I2cHandle) != HAL_I2C_STATE_READY)
	{
	}
	while (HAL_I2C_Master_Transmit_DMA(&I2cHandle, DevAddress, pData, Size) != HAL_OK)
	{
		Error_Handler();
	}
}
//void IIC_recieve_DMA( uint16_t DevAddress, uint8_t *pData, uint16_t Size)
//{
//	/*判断当前I2C状态*/
//	while (HAL_I2C_GetState(&I2cHandle) != HAL_I2C_STATE_READY)
//	{
//	}
//	while (HAL_I2C_Master_Receive_DMA(&I2cHandle, DevAddress, pData, Size) != HAL_OK)
//	{
//		Error_Handler();
//	}
//}
/**
  * @brief  字符比较函数
  * @param  pBuffer1：待比较缓冲区1
  * @param  pBuffer2：待比较缓冲区2
  * @param  BufferLength：待比较字符的个数
  * @retval 0：比较值相同；1：比较值不同
  */
static uint8_t APP_Buffercmp8(uint8_t* pBuffer1, uint8_t* pBuffer2, uint8_t BufferLength)
{
  while (BufferLength--)
  {
    if (*pBuffer1 != *pBuffer2)
    {
      return 1;
    }
    pBuffer1++;
    pBuffer2++;
  }

  return 0;
}
#endif
//#ifndef __IIC_SOFTWARE_H__
//#define __IIC_SOFTWARE_H__

//#ifdef __cplusplus
//extern "C" {
//#endif
//#define GRAY_ADDRESS 0xA0 //  从机I2C地址
//#include "main.h"
////void MyI2C_Init(void);
////void MyIIC_Start(void);
////void MyIIC_Stop(void);
////void MyIIC_SendByte(uint8_t Byte);
////uint8_t MyIIC_RceiveByte(void);
////void MyIIC_SendAck(uint8_t Ackbit);
////uint8_t MyIIC_RceiveAck();
////void GRAY_IIC(uint8_t Address,uint8_t *Data);

//void MyIIC_Init(void);
//uint8_t IIC_CheckStart(void);
//uint8_t IIC_CheckStop();
//void IIC_SendByte(uint8_t Byte);
//unsigned int IIC_Addr_RW(void);
//void MyIIC_SendAck(uint8_t Ackbit);
//uint8_t MyIIC_ReceiveAck(void);
//#ifdef __cplusplus
//}
//#endif

//#endif /* __ADC_H__ */
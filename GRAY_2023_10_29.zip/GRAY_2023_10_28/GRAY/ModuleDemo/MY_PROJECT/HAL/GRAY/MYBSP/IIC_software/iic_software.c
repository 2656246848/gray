//#include "iic_software.h"

//#define IIC_PORT 	GPIOF
//#define SCL_PIN 	GPIO_PIN_0
//#define SDA_PIN 	GPIO_PIN_1

////SCL电平设置
//void Set_SCL(uint8_t level) {
//    if (level == 1) {
//        LL_GPIO_SetOutputPin(IIC_PORT, LL_GPIO_PIN_0);  // 设置引脚为高电平
//    } else if (level == 0) {
//        LL_GPIO_ResetOutputPin(IIC_PORT, LL_GPIO_PIN_0);  // 设置引脚为低电平
//    }
//    // 可以添加错误处理逻辑以处理无效的参数
//	LL_uDelay(10);//延时10us
//}
////SDA
//void Set_SDA(uint8_t level) {
//    if (level == 1) {
//        LL_GPIO_SetOutputPin(IIC_PORT, LL_GPIO_PIN_1);  // 设置引脚为高电平
//    } else if (level == 0) {
//        LL_GPIO_ResetOutputPin(IIC_PORT, LL_GPIO_PIN_1);  // 设置引脚为低电平
//    }
//    // 可以添加错误处理逻辑以处理无效的参数
//	LL_uDelay(10);//延时10us
//}

//uint8_t Read_SDA(void)
//{
//	if (HAL_GPIO_ReadPin(IIC_PORT,SDA_PIN)!=0)
//	{
//	   return 1;
//	}
//	else
//	{
//		return 0;
//	}
//}

//uint8_t Read_SCL(void)
//{
//	if (HAL_GPIO_ReadPin(IIC_PORT,SCL_PIN) !=0)
//	{
//	   return 1;
//	}
//	else
//	{
//		return 0;
//	}
//}

//////初始化
////void MyI2C_Init(void)
////{
////	//时钟使能
////  LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOF);
////	
////  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
////  GPIO_InitStruct.Pin = LL_GPIO_PIN_0|LL_GPIO_PIN_1;
////  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT ;
////  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
////  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_OPENDRAIN;//开漏输出
////  GPIO_InitStruct.Pull = LL_GPIO_PULL_UP;
////  LL_GPIO_Init(GPIOF, &GPIO_InitStruct);
////  LL_GPIO_SetOutputPin(IIC_PORT, LL_GPIO_PIN_1|LL_GPIO_PIN_0); 
////}

////void MyIIC_Start(void)
////{
////	Set_SDA(1);
////	Set_SCL(1);
////	Set_SDA(0);
////	Set_SCL(0);
////}

////void MyIIC_Stop(void)
////{
////	Set_SDA(0);
////	Set_SCL(1);
////	Set_SDA(1);
////}

//////发数据
////void MyIIC_SendByte(uint8_t Byte)
////{
////	uint8_t i;
////	for(i=0;i<8;i++)
////	{
////		Set_SDA(Byte & 0x80>>i);//从最高位到最低位
////		Set_SCL(1);
////		Set_SCL(0);
////	}
////}
//////读数据
////uint8_t MyIIC_RceiveByte(void)
////{
////	uint8_t i,Byte =0x00;
////	Set_SDA(1);
////	for(i=0;i<8;i++)
////	{
////		Set_SCL(1);
////		if(Read_SDA() == 1){Byte |= (0x80>>i);}
////		Set_SCL(0);
////	}
////	return Byte;
////}

//////发数据a
////void MyIIC_SendAck(uint8_t Ackbit)
////{
////		Set_SDA(Ackbit);//从最高位到最低位
////		Set_SCL(1);
////		Set_SCL(0);
////	
////}
//////读数据
////uint8_t MyIIC_RceiveAck(void)
////{
////	uint8_t Ackbit;
////	Set_SDA(1);
////	Set_SCL(1);
////	Ackbit = Read_SDA();
////	Set_SCL(0);
////	return Ackbit;
////}

////void GRAY_IIC(uint8_t Address,uint8_t *Data)
////{
////	MyIIC_Start();
////	MyIIC_SendByte(0xA0);
////	MyIIC_RceiveAck();
////	for(uint8_t i=0;i<6;i++)
////	{
////		MyIIC_SendByte(Address);
////		MyIIC_RceiveAck();
////		MyIIC_SendByte(*(Data+i));
////		MyIIC_RceiveAck();
////	}
////	MyIIC_Stop();
////}


//void MyIIC_Init(void)
//{
//	//时钟使能
//  LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOF);
//	
//  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
//  GPIO_InitStruct.Pin = LL_GPIO_PIN_0|LL_GPIO_PIN_1;
//  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT ;
//  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
//  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_OPENDRAIN;//开漏输出
//  GPIO_InitStruct.Pull = LL_GPIO_PULL_UP;
//  LL_GPIO_Init(GPIOF, &GPIO_InitStruct);
//  LL_GPIO_SetOutputPin(IIC_PORT, LL_GPIO_PIN_1|LL_GPIO_PIN_0); 
//}


//uint8_t IIC_CheckStart(void)
//{
//	//检测开始信号
//	while(Read_SDA()&&Read_SCL());
//	if(!Read_SDA()&&!Read_SCL())
//	{
//		return 1;
//	}		
//	else
//	{
//		return 0;
//	}
//}

////检测结束信号
//uint8_t IIC_CheckStop() {
//    // 等待SCL和SDA的状态
//    while (Read_SCL() && !Read_SDA());
//    // 当SCL为高电平，而SDA由低电平变为高电平时，表示结束信号
//    if (Read_SDA()) {
//        return 1; // 检测到结束信号
//    } else {
//        return 0; // 没有检测到结束信号
//    }
//}

//void IIC_SendByte(uint8_t Byte) {

//    // 逐位发送数据
//    for (int i = 7; i >= 0; i--) {
//		Set_SCL(1);
//        // 发送数据位的第i位
//        if (Byte & (0x80 << i)) {
//            // 如果是1，拉高SDA引脚
//            Set_SDA(1);
//        } else {
//            // 如果是0，拉低SDA引脚
//            Set_SDA(0);
//        }
//		Set_SCL(0);
//    }
//}

////从机接收一个字节
//unsigned int IIC_Addr_RW(void)
//{
//	unsigned int Addr_Check=0x00,i=0;
//	//while (!IIC_CheckStart());
//	for(i=0;i<8;i++)
//	{
//		while(Read_SCL());
//		while(Read_SCL()==0);
//		Addr_Check <<=1;
//		if(Read_SDA() == 1){
//			Addr_Check |= 0x01;
//		}else{
//			Addr_Check |= 0x00;
//		}		
//	}
//	//while (!IIC_CheckStop());
//	return Addr_Check;    
//}
////应答信号：0为应答
//void MyIIC_SendAck(uint8_t Ackbit)
//{
//	Set_SDA(Ackbit);//从最高位到最低位
//	Set_SCL(1);
//	Set_SCL(0);
//	
//}
////读
//uint8_t MyIIC_ReceiveAck(void)
//{
//	uint8_t Ackbit;
//	Set_SDA(1);
//	Set_SCL(1);
//	Ackbit = Read_SDA();
//	Set_SCL(0);
//	return Ackbit;
//}



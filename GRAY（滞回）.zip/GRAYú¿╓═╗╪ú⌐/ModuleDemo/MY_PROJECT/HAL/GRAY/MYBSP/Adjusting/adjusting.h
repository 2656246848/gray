#ifndef __ADJUSTING_H__
#define __ADJUSTING_H__
#include "main.h" 
#include "stdio.h"
#include "stdlib.h"

//校验信息保存,数组长度由光照等级数决定
typedef struct{
//	uint16_t max[2];//最大值
//	uint16_t min[2];
	uint32_t max_average[2];//最大值链表平均值
	uint32_t min_average[2];
}TESTDATA;

// 结构体定义，表示链表节点
struct Node {
    uint16_t site;
    struct Node *next;//指向下一个节点
};

//extern uint8_t node_num[10];
void insertSorted_max(struct Node **head, uint16_t value,char num);
void insertSorted_min(struct Node **head, uint16_t value,char num);
uint16_t absolute(int16_t number);
uint8_t findMaxIndex(uint16_t array[], uint8_t length);
//void freeLinkedList(struct Node **head);
void freeLinkedList(struct Node **head,uint32_t *sh);
void print_list(struct Node **head);
//uint16_t cua_cri(TESTDATA* p1);
void cua_cri(TESTDATA* p1,uint16_t* v);
void cua_cri2(TESTDATA* p1,uint16_t* v);
void cua_cri3(TESTDATA* p1,uint16_t* v);
#endif
